module.exports = {
  trailingComma: "none",
  printWidth: 128,
  singleQuote: false
};
