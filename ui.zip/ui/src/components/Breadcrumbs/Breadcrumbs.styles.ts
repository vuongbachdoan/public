import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles()(() => ({
  separator: {
    marginLeft: 0,
    marginRight: 0
  }
}));

export default useStyles;
