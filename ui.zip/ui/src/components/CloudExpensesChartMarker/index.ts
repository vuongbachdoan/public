import CloudExpensesChartMarker from "./CloudExpensesChartMarker";

export default CloudExpensesChartMarker;
