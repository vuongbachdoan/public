import CloudAccountsTable from "./CloudAccountsTable";

export default CloudAccountsTable;
