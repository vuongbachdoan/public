import CopyTextField from "./CopyTextField";

export default CopyTextField;
