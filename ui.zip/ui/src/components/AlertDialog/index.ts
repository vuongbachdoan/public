import AlertDialog from "./AlertDialog";

export default AlertDialog;
