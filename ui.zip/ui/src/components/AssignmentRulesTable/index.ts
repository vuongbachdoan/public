import AssignmentRulesTable from "./AssignmentRulesTable";

export default AssignmentRulesTable;
