import ClusterTypesTable from "./ClusterTypesTable";

export default ClusterTypesTable;
