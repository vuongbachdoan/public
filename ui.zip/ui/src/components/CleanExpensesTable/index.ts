import CleanExpensesTable from "./CleanExpensesTable";

export default CleanExpensesTable;
