import CapabilityWrapper from "./CapabilityWrapper";

export default CapabilityWrapper;
