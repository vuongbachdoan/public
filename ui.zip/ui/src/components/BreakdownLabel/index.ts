import BreakdownLabel, { getBreakdownLabelText } from "./BreakdownLabel";

export default BreakdownLabel;
export { getBreakdownLabelText };
