import ApiSuccessAlert from "./ApiSuccessAlert";

export default ApiSuccessAlert;
