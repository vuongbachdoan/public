import BINextExportTimeLabel from "./BINextExportTimeLabel";

export default BINextExportTimeLabel;
