import ApolloProvider from "./ApolloProvider";

export default ApolloProvider;
