import ArchivedRecommendationAccordionTitle from "./ArchivedRecommendationAccordionTitle";

export default ArchivedRecommendationAccordionTitle;
