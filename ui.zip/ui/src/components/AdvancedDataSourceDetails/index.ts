import AdvancedDataSourceDetails from "./AdvancedDataSourceDetails";

export default AdvancedDataSourceDetails;
