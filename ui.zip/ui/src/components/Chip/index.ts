import Chip from "./Chip";

export default Chip;
