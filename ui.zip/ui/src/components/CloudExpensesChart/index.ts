import CloudExpensesChart from "./CloudExpensesChart";

export default CloudExpensesChart;
