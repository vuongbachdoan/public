import ApiErrorMessage from "./ApiErrorMessage";

export default ApiErrorMessage;
