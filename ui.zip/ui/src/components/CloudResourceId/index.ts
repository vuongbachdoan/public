import CloudResourceId from "./CloudResourceId";

export default CloudResourceId;
