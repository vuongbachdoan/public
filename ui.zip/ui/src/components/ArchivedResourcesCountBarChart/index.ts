import ArchivedResourcesCountBarChart from "./ArchivedResourcesCountBarChart";

export default ArchivedResourcesCountBarChart;
