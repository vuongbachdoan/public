import ArchivedRecommendationDescription from "./ArchivedRecommendationDescription";

export default ArchivedRecommendationDescription;
