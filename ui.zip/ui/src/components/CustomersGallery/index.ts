import CustomersGallery from "./CustomersGallery";

export default CustomersGallery;
