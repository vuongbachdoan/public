import CloudAccountsOverview from "./CloudAccountsOverview";
import CloudAccountsOverviewMocked from "./CloudAccountsOverviewMocked";

export default CloudAccountsOverview;
export { CloudAccountsOverviewMocked };
