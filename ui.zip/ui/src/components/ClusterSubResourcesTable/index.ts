import ClusterSubResourcesTable from "./ClusterSubResourcesTable";

export default ClusterSubResourcesTable;
