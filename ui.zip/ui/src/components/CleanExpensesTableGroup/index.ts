import CleanExpensesTableGroup from "./CleanExpensesTableGroup";

export default CleanExpensesTableGroup;
