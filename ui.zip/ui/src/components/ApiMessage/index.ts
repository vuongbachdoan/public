import ApiMessage from "./ApiMessage";

export default ApiMessage;
