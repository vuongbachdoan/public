import CollapsableTableCell from "./CollapsableTableCell";

export default CollapsableTableCell;
