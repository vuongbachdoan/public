import CompactFormattedNumber, { formatCompactNumber } from "./CompactFormattedNumber";

export default CompactFormattedNumber;
export { formatCompactNumber };
