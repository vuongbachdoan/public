import ActionBarResourceNameTitleText from "./ActionBarResourceNameTitleText";

export default ActionBarResourceNameTitleText;
