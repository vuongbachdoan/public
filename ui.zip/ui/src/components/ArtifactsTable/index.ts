import ArtifactsTable from "./ArtifactsTable";

export default ArtifactsTable;
