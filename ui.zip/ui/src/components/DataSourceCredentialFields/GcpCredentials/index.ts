import GcpCredentials, { FIELD_NAMES } from "./GcpCredentials";

export { FIELD_NAMES };
export default GcpCredentials;
