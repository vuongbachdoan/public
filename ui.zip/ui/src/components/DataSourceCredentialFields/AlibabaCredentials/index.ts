import AlibabaCredentials, { FIELD_NAMES } from "./AlibabaCredentials";

export { FIELD_NAMES };
export default AlibabaCredentials;
