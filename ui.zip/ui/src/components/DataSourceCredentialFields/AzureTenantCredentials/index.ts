import AzureTenantCredentials, { FIELD_NAMES } from "./AzureTenantCredentials";

export { FIELD_NAMES };
export default AzureTenantCredentials;
