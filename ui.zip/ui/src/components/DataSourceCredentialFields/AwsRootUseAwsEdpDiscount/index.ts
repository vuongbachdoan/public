import AwsRootUseAwsEdpDiscount, { FIELD_NAMES } from "./AwsRootUseAwsEdpDiscount";

export { FIELD_NAMES };
export default AwsRootUseAwsEdpDiscount;
