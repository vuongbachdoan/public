import CloudLabel from "./CloudLabel";

export default CloudLabel;
