import CellCaption from "./CellCaption";

export default CellCaption;
