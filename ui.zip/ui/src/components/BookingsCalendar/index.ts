import BookingsCalendar from "./BookingsCalendar";

export default BookingsCalendar;
