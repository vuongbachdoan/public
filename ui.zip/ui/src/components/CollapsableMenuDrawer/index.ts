import CollapsableMenuDrawer from "./CollapsableMenuDrawer";

export default CollapsableMenuDrawer;
