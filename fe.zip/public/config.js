window.optscale = window.optscale || {};
