import BarChartLoader from "./BarChartLoader";

export default BarChartLoader;
