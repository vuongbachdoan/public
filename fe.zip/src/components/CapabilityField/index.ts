import CapabilityField from "./CapabilityField";

export default CapabilityField;
