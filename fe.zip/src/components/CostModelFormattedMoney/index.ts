import CostModelFormattedMoney from "./CostModelFormattedMoney";

export default CostModelFormattedMoney;
