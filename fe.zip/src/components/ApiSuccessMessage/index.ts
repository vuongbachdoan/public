import ApiSuccessMessage from "./ApiSuccessMessage";

export default ApiSuccessMessage;
