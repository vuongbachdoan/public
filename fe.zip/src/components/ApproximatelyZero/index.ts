import ApproximatelyZero, { formatApproximatelyZero } from "./ApproximatelyZero";

export { formatApproximatelyZero };

export default ApproximatelyZero;
