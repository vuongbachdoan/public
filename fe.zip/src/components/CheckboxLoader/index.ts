import CheckboxLoader from "./CheckboxLoader";

export default CheckboxLoader;
