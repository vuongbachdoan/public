import AcceptInvitation from "./AcceptInvitation";

export default AcceptInvitation;
