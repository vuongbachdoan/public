import prepareData from "./prepareData";

export { prepareData };
