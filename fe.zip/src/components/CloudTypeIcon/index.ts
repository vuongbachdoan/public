import CloudTypeIcon from "./CloudTypeIcon";

export default CloudTypeIcon;
