import ApplyResourcePerspective from "./ApplyResourcePerspective";

export default ApplyResourcePerspective;
