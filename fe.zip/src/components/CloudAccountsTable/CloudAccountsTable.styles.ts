import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles()(() => ({
  nameCellWrapper: {
    display: "flex",
    alignItems: "center"
  }
}));

export default useStyles;
