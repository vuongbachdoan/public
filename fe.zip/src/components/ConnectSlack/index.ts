import ConnectSlack from "./ConnectSlack";

export default ConnectSlack;
