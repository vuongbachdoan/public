import AggregateFunctionFormattedMessage, {
  AGGREGATE_FUNCTION,
  AGGREGATE_FUNCTION_MESSAGE_ID
} from "./AggregateFunctionFormattedMessage";

export default AggregateFunctionFormattedMessage;
export { AGGREGATE_FUNCTION, AGGREGATE_FUNCTION_MESSAGE_ID };
