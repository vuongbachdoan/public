import ArchivedRecommendations from "./ArchivedRecommendations";

export default ArchivedRecommendations;
