import { CHANGE_SORT_GROUPS_BY } from "./actionTypes";

export const changeSortGroupsBy = (value) => ({
  type: CHANGE_SORT_GROUPS_BY,
  value
});
