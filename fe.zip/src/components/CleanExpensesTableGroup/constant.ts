export const TOTAL_EXPENSES = "totalExpenses";
export const COUNT = "count";
