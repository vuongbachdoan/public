import ChartLegendToggle from "./ChartLegendToggle";

export default ChartLegendToggle;
