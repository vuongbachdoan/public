import CapabilityCard from "./CapabilityCard";

export default CapabilityCard;
