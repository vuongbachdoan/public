import ChipFiltersWrapper from "./ChipFiltersWrapper";

export default ChipFiltersWrapper;
