import ContentBackdropLoader from "./ContentBackdropLoader";

export default ContentBackdropLoader;
