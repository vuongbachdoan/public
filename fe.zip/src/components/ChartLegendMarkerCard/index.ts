import ChartLegendMarkerCard from "./ChartLegendMarkerCard";

export default ChartLegendMarkerCard;
