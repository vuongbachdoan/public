import CanvasBarChart from "./CanvasBarChart";

export default CanvasBarChart;
