import { makeStyles } from "tss-react/mui";

const useStyles = makeStyles()({
  hover: {
    cursor: "pointer !important"
  }
});

export default useStyles;
