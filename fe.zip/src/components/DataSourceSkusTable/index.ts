import DataSourceSkusTable from "./DataSourceSkusTable";

export default DataSourceSkusTable;
