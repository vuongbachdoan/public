import CloudCostComparisonModalContent from "./CloudCostComparisonModalContent";

export default CloudCostComparisonModalContent;
