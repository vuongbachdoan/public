import DetailsSummaryList from "./DetailsSummaryList";

export default DetailsSummaryList;
