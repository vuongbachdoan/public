import TargetStorageSummaryList from "./TargetStorageSummaryList";

export default TargetStorageSummaryList;
