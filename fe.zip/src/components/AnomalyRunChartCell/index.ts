import AnomalyRunChartCell from "./AnomalyRunChartCell";

export default AnomalyRunChartCell;
