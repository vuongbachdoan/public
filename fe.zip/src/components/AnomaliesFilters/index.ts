import AnomaliesFilters from "./AnomaliesFilters";

export default AnomaliesFilters;
