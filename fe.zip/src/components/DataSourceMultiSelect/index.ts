import DataSourceMultiSelect from "./DataSourceMultiSelect";

export default DataSourceMultiSelect;
