import DataSourceDetails from "./DataSourceDetails";

export default DataSourceDetails;
