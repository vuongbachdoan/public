import DataSourceNodesTable from "./DataSourceNodesTable";

export default DataSourceNodesTable;
