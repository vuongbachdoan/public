import { cpu } from "./cpu";
import { flavors } from "./flavors";
import { ram } from "./ram";

export { cpu, ram, flavors };
