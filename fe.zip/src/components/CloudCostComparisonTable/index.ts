import CloudCostComparisonTable from "./CloudCostComparisonTable";

export default CloudCostComparisonTable;
