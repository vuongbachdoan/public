import CopyText from "./CopyText";

export default CopyText;
