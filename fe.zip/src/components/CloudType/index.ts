import CloudType from "./CloudType";

export default CloudType;
