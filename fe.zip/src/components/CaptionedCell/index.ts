import CaptionedCell from "./CaptionedCell";

export default CaptionedCell;
