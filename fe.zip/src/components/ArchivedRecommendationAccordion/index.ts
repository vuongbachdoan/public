import ArchivedRecommendationAccordion from "./ArchivedRecommendationAccordion";

export default ArchivedRecommendationAccordion;
