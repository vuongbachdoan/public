import AzureSubscriptionCredentials, { FIELD_NAMES } from "./AzureSubscriptionCredentials";

export { FIELD_NAMES };
export default AzureSubscriptionCredentials;
