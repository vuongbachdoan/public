import AwsRootCredentials, { FIELD_NAMES } from "./AwsRootCredentials";

export { FIELD_NAMES };
export default AwsRootCredentials;
