import NebiusCredentials from "./NebiusCredentials";

export default NebiusCredentials;
