import GcpTenantCredentials, { FIELD_NAMES } from "./GcpTenantCredentials";

export { FIELD_NAMES };
export default GcpTenantCredentials;
