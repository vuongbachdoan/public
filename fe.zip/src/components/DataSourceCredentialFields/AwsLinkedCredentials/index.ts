import AwsLinkedCredentials, { FIELD_NAMES } from "./AwsLinkedCredentials";

export { FIELD_NAMES };
export default AwsLinkedCredentials;
