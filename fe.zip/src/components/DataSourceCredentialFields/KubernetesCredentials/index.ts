import KubernetesCredentials, { FIELD_NAMES } from "./KubernetesCredentials";

export { FIELD_NAMES };
export default KubernetesCredentials;
