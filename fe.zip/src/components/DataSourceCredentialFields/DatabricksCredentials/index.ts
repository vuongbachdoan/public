import DatabricksCredentials, { FIELD_NAMES } from "./DatabricksCredentials";

export { FIELD_NAMES };
export default DatabricksCredentials;
