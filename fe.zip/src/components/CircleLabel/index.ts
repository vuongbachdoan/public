import CircleLabel from "./CircleLabel";

export default CircleLabel;
