import AssignmentRules from "./AssignmentRules";
import AssignmentRulesMocked from "./AssignmentRulesMocked";

export default AssignmentRules;
export { AssignmentRulesMocked };
