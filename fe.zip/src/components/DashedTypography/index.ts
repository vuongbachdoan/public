import DashedTypography from "./DashedTypography";

export default DashedTypography;
