import CloudAccountDetails from "./CloudAccountDetails";

export default CloudAccountDetails;
