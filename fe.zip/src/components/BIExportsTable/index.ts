import BIExportsTable from "./BIExportsTable";

export default BIExportsTable;
