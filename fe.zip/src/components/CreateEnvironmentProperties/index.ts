import CreateEnvironmentProperties from "./CreateEnvironmentProperties";

export default CreateEnvironmentProperties;
